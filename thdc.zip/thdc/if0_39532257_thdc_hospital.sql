-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql213.infinityfree.com
-- Generation Time: Jul 31, 2025 at 10:55 AM
-- Server version: 11.4.7-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_39532257_thdc_hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `prescriptions`
--

CREATE TABLE `prescriptions` (
  `id` int(11) NOT NULL,
  `opd_reg_no` varchar(20) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `medicine` text DEFAULT NULL,
  `lab_test` text DEFAULT NULL,
  `status` enum('pending','completed','not_available') DEFAULT 'pending'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `prescriptions`
--

INSERT INTO `prescriptions` (`id`, `opd_reg_no`, `doctor_id`, `medicine`, `lab_test`, `status`) VALUES
(1, 'OPD-1', 9, 'aa,bb', '', 'not_available'),
(2, 'opd-1', 9, 'aa,bb', 'vitaminb12', 'not_available'),
(3, 'opd-4', 9, '', '', 'not_available'),
(4, 'opd-3', 9, '', '', 'completed'),
(5, 'opd-2', 9, '', '', 'completed'),
(6, 'opd-2', 9, '', '', 'completed'),
(7, 'opd-2', 9, 'aa,bb,cs', 'iron', 'completed'),
(8, 'OPD-2', 9, 'aa,bb,cs', 'iron', 'pending'),
(9, 'opd90', 9, '1= ', 'no', 'pending'),
(10, 'opd-2', 9, 'dd', 'no', 'pending'),
(11, 'OPD-842464', 9, '', '', 'completed'),
(12, 'OPD-960383', 9, 'pcm', 'iron', 'not_available');

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `opd_reg_no` varchar(20) NOT NULL,
  `reg_date` datetime NOT NULL,
  `name` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `category` enum('A','B') NOT NULL,
  `employee_name` varchar(100) DEFAULT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `workplace` varchar(100) DEFAULT NULL,
  `recommended_doctor` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`opd_reg_no`, `reg_date`, `name`, `age`, `gender`, `mobile`, `email`, `category`, `employee_name`, `relationship`, `workplace`, `recommended_doctor`) VALUES
('OPD-1', '2000-01-12 11:20:00', 'anita', 22, 'Female', '9999999999', 'anshikabhatt011@gmail.com', 'B', '', 'Self', '', 'dr.pathak'),
('OPD-2', '1989-04-11 03:11:00', 'ram', 44, 'Male', '2222222224', 'anshikabhatt011@gmail.com', 'A', 'sita', 'Child', 'tehri', 'dr.pathak'),
('opd-3', '0000-00-00 00:00:00', 'gita', 33, 'Female', '9822222222', 'anshikabhatt011@gmail.com', 'A', 'gita', 'Self', 'tehri', 'dr.pathak'),
('opd-4', '2000-04-12 12:34:00', 'shivansh', 33, 'Male', '9368444444', 'anshikabhatt011@gmail.com', 'A', 'shivansh', 'Self', 'tehri', 'dr.pathak'),
('OPD-440532', '2008-02-22 11:23:00', 'aa', 33, 'Male', '9368275587', 'anshihi7@gmail.com', 'B', '', 'Self', '', 'dr.pathak'),
('OPD-969887', '2009-02-22 04:04:00', 'arav', 22, 'Female', '9999999999', 'anshikabhatt011@gmail.com', 'A', 'arav', 'Self', 'tehri', 'dr.pathak'),
('opd10', '2009-12-22 11:23:00', 'anshika', 11, 'Female', '2222222224', 'anshikabhatt011@gmail.com', 'B', '', 'Self', '', 'dr.pathak'),
('opd23', '4233-03-22 04:44:00', 'bb', 55, 'Female', '9368275587', 'anshihi7@gmail.com', 'A', 'sita', 'Self', 'tehri', 'dr.pathak'),
('op90', '4399-03-22 04:44:00', 'mm', 99, 'Other', '9999999999', 'anshikabhatt011@gmail.com', 'B', '', 'Self', '', 'dr.pathak'),
('OPD-842464', '2025-07-25 10:02:00', 'Vishal Kumar', 22, 'Male', '7461932895', 'luckyrounak2895@gmail.com', 'A', 'vishu', 'Self', 'abcd', 'dr gulati'),
('OPD-976884', '2025-07-25 04:36:00', 'Lucky Rounak', 134, 'Male', '3254657556', 'abc@gmail', 'A', 'vishu', 'Self', '', 'dr gulati'),
('OPD-775994', '2025-07-25 04:40:00', 'faddg', 34, 'Male', '5656565656', 'luckyrounak2895@gmail.com', 'A', 'vishu', 'Self', '', 'dr gulati'),
('OPD-960383', '2025-07-30 05:31:00', 'ashu', 22, 'Male', '9368275587', 'anshihi7@gmail.com', 'A', 'arav', 'Self', '', 'dr.pathak'),
('OPD-271174', '2025-07-30 05:31:00', 'aaaa', 77, 'Other', '9368275587', 'anshihi7@gmail.com', 'B', '', 'Self', 'tehri', 'dr.pathak');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('receptionist','doctor','pharmacist','lab','patient','admin') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(4, 'admin', 'admin123', 'admin'),
(9, 'doctor', 'doctor123', 'doctor'),
(7, 'pharmacist', 'pharmacist123', 'pharmacist'),
(8, 'labtech', 'labtech123', 'lab'),
(5, 'dr.tehri', '@tehri', 'doctor'),
(6, 'reception', 'reception123', 'receptionist'),
(10, 'lab', 'lab123', 'lab');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `opd_reg_no` (`opd_reg_no`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- Indexes for table `registrations`
--
ALTER TABLE `registrations`
  ADD PRIMARY KEY (`opd_reg_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `prescriptions`
--
ALTER TABLE `prescriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
