<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set error log file
ini_set('log_errors', 1);
ini_set('error_log', 'error.log');

// Check and include config.php
if (file_exists('config.php')) {
    try {
        include 'config.php';
        error_log("patient.php: config.php included successfully");
    } catch (Exception $e) {
        error_log("patient.php: Failed to include config.php - " . $e->getMessage());
        die("Error: Unable to include config.php. Check file path and permissions.");
    }
} else {
    error_log("patient.php: config.php not found");
    die("Error: config.php file is missing.");
}

// Verify database connection
try {
    $conn->query("SELECT 1");
    error_log("patient.php: Database connection successful");
} catch (PDOException $e) {
    error_log("patient.php: Database connection failed - " . $e->getMessage());
    die("Error: Database connection failed. Please check config.php and database settings.");
}

// Check if TCPDF is available
$tcpdf_available = file_exists('tcpdf/tcpdf.php');
if ($tcpdf_available) {
    try {
        require_once 'tcpdf/tcpdf.php';
        error_log("patient.php: TCPDF included successfully");
    } catch (Exception $e) {
        error_log("patient.php: Failed to include TCPDF - " . $e->getMessage());
        $tcpdf_available = false;
    }
} else {
    error_log("patient.php: TCPDF not found at tcpdf/tcpdf.php");
}

$mobile = '';
$registrations = [];
$prescriptions = [];
$pharmacy_records = [];
$lab_results = [];
$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['download_pdf'])) {
    $mobile = trim($_POST['mobile'] ?? '');
    error_log("patient.php: Mobile number submitted - '$mobile'");

    if (empty($mobile)) {
        error_log("patient.php: Mobile number is empty");
        $error_message = "Please enter a mobile number!";
    } elseif (!preg_match('/^[0-9]{10}$/', $mobile)) {
        error_log("patient.php: Invalid mobile number format - '$mobile'");
        $error_message = "Please enter a valid 10-digit mobile number!";
    } else {
        try {
            // Fetch patient details from registrations table
            $stmt = $conn->prepare("SELECT * FROM registrations WHERE mobile = :mobile");
            error_log("patient.php: Executing query: SELECT * FROM registrations WHERE mobile = '$mobile'");
            $stmt->execute([':mobile' => $mobile]);
            $registrations = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (empty($registrations)) {
                error_log("patient.php: No records found for mobile number '$mobile'");
                $error_message = "No records found for this mobile number!";
            } else {
                // Get all opd_reg_no values for this mobile and normalize to uppercase
                $opd_reg_nos = array_map('strtoupper', array_column($registrations, 'opd_reg_no'));

                // Log the OPD registration numbers for debugging
                error_log("patient.php: OPD registration numbers - " . implode(',', $opd_reg_nos));

                // Fetch prescriptions
                if (!empty($opd_reg_nos)) {
                    $stmt = $conn->prepare("SELECT * FROM prescriptions WHERE UPPER(opd_reg_no) IN (" . implode(',', array_fill(0, count($opd_reg_nos), '?')) . ")");
                    error_log("patient.php: Executing query: SELECT * FROM prescriptions WHERE UPPER(opd_reg_no) IN (" . implode(',', $opd_reg_nos) . ")");
                    try {
                        $stmt->execute($opd_reg_nos);
                        $prescriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        error_log("patient.php: Fetched " . count($prescriptions) . " prescription records");
                    } catch (PDOException $e) {
                        error_log("patient.php: Prescription query failed - " . $e->getMessage());
                        $prescriptions = [];
                        $error_message = "Error fetching prescriptions: " . htmlspecialchars($e->getMessage());
                    }
                } else {
                    error_log("patient.php: No OPD registration numbers found for mobile '$mobile'");
                    $prescriptions = [];
                }

                // Fetch pharmacy records (if table exists)
                try {
                    $stmt = $conn->prepare("SELECT pr.*, ph.name AS pharmacist_name 
                                           FROM pharmacy_records pr 
                                           LEFT JOIN pharmacists ph ON pr.pharmacist_id = ph.id 
                                           WHERE UPPER(pr.opd_reg_no) IN (" . implode(',', array_fill(0, count($opd_reg_nos), '?')) . ")");
                    error_log("patient.php: Executing query: SELECT pr.*, ph.name AS pharmacist_name FROM pharmacy_records pr LEFT JOIN pharmacists ph ON pr.pharmacist_id = ph.id WHERE UPPER(pr.opd_reg_no) IN (" . implode(',', $opd_reg_nos) . ")");
                    $stmt->execute($opd_reg_nos);
                    $pharmacy_records = $stmt->fetchAll(PDO::FETCH_ASSOC);
                } catch (PDOException $e) {
                    error_log("patient.php: Pharmacy records query failed - " . $e->getMessage());
                    $pharmacy_records = [];
                }

                // Fetch lab results (if table exists)
                try {
                    $stmt = $conn->prepare("SELECT lr.*, lt.name AS test_name 
                                           FROM lab_results lr 
                                           LEFT JOIN lab_tests lt ON lr.test_id = lt.id 
                                           WHERE UPPER(lr.opd_reg_no) IN (" . implode(',', array_fill(0, count($opd_reg_nos), '?')) . ")");
                    error_log("patient.php: Executing query: SELECT lr.*, lt.name AS test_name FROM lab_results lr LEFT JOIN lab_tests lt ON lr.test_id = lt.id WHERE UPPER(lr.opd_reg_no) IN (" . implode(',', $opd_reg_nos) . ")");
                    $stmt->execute($opd_reg_nos);
                    $lab_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                } catch (PDOException $e) {
                    error_log("patient.php: Lab results query failed - " . $e->getMessage());
                    $lab_results = [];
                }
            }
        } catch (PDOException $e) {
            error_log("patient.php: Database error - " . $e->getMessage());
            $error_message = "Database error: " . htmlspecialchars($e->getMessage());
        }
    }
}

// Handle PDF download
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['download_pdf']) && !empty($registrations)) {
    if (!$tcpdf_available) {
        error_log("patient.php: PDF generation skipped - TCPDF not available");
        $error_message = "PDF generation is not available. Please contact the administrator.";
    } else {
        try {
            $pdf = new TCPDF();
            $pdf->SetCreator(PDF_CREATOR);
            $pdf->SetAuthor('THDC India Limited');
            $pdf->SetTitle('Patient Details');
            $pdf->SetHeaderData('', 0, 'THDC India Limited - Patient Details', "Hospital Bhagirathi Puram, Tehri\nMobile: $mobile");
            $pdf->setHeaderFont([PDF_FONT_NAME_MAIN, '', 10]);
            $pdf->SetMargins(15, 20, 15);
            $pdf->AddPage();

            // Patient Details
            $html = '<h2>Patient Details</h2>';
            $html .= '<h3>Welcome, ' . htmlspecialchars($registrations[0]['name'] ?? 'Patient') . '</h3>';
            $html .= '<p><strong>Mobile Number:</strong> ' . htmlspecialchars($mobile) . '</p>';

            // Registrations
            $html .= '<h3>Previous Registrations</h3>';
            foreach ($registrations as $reg) {
                $html .= '<div style="border:1px solid #ccc;padding:10px;margin-bottom:10px;">';
                $html .= '<p><strong>OPD Reg No:</strong> ' . htmlspecialchars($reg['opd_reg_no']) . '</p>';
                $html .= '<p><strong>Name:</strong> ' . htmlspecialchars($reg['name']) . '</p>';
                $html .= '<p><strong>Date:</strong> ' . (new DateTime($reg['reg_date']))->format('d-m-Y') . '</p>';
                $html .= '<p><strong>Department:</strong> ' . htmlspecialchars($reg['recommended_doctor'] ?? 'N/A') . '</p>';
                $html .= '</div>';
            }

            // Prescriptions
            $html .= '<h3>Doctor Prescriptions</h3>';
            if (empty($prescriptions)) {
                $html .= '<p>No prescription records found.</p>';
            } else {
                foreach ($prescriptions as $pres) {
                    $html .= '<div style="border:1px solid #ccc;padding:10px;margin-bottom:10px;">';
                    $html .= '<h4>' . ($pres['medicine'] ? 'Medicine Prescription' : 'Lab Test Prescription') . '</h4>';
                    $html .= '<p><strong>OPD Reg No:</strong> ' . htmlspecialchars($pres['opd_reg_no']) . '</p>';
                    $html .= '<p><strong>Medicine:</strong> ' . htmlspecialchars($pres['medicine'] ?? 'N/A') . '</p>';
                    $html .= '<p><strong>Lab Test:</strong> ' . htmlspecialchars($pres['lab_test'] ?? 'N/A') . '</p>';
                    $html .= '<p><strong>Status:</strong> ' . htmlspecialchars($pres['status'] ?? 'N/A') . '</p>';
                    $html .= '</div>';
                }
            }

            // Pharmacy Records
            $html .= '<h3>Pharmacy Records</h3>';
            if (empty($pharmacy_records)) {
                $html .= '<p>No pharmacy records found.</p>';
            } else {
                foreach ($pharmacy_records as $pharm) {
                    $html .= '<div style="border:1px solid #ccc;padding:10px;margin-bottom:10px;">';
                    $html .= '<p><strong>Pharmacist:</strong> ' . htmlspecialchars($pharm['pharmacist_name'] ?? 'N/A') . '</p>';
                    $html .= '<p><strong>Date:</strong> ' . (new DateTime($pharm['dispense_date']))->format('d-m-Y') . '</p>';
                    $html .= '<p><strong>Medication:</strong> ' . htmlspecialchars($pharm['medication'] ?? 'N/A') . '</p>';
                    $html .= '<p><strong>Quantity:</strong> ' . htmlspecialchars($pharm['quantity'] ?? 'N/A') . '</p>';
                    $html .= '<p><strong>Status:</strong> ' . htmlspecialchars($pharm['status'] ?? 'N/A') . '</p>';
                    $html .= '</div>';
                }
            }

            // Lab Results
            $html .= '<h3>Lab Results</h3>';
            if (empty($lab_results)) {
                $html .= '<p>No lab results found.</p>';
            } else {
                foreach ($lab_results as $lab) {
                    $html .= '<div style="border:1px solid #ccc;padding:10px;margin-bottom:10px;">';
                    $html .= '<p><strong>Test Name:</strong> ' . htmlspecialchars($lab['test_name'] ?? 'N/A') . '</p>';
                    $html .= '<p><strong>Date:</strong> ' . (new DateTime($lab['test_date']))->format('d-m-Y') . '</p>';
                    $html .= '<p><strong>Result:</strong> ' . htmlspecialchars($lab['result'] ?? 'N/A') . '</p>';
                    $html .= '<p><strong>Reference Range:</strong> ' . htmlspecialchars($lab['reference_range'] ?? 'N/A') . '</p>';
                    $html .= '<p><strong>Status:</strong> ' . htmlspecialchars($lab['status'] ?? 'N/A') . '</p>';
                    $html .= '</div>';
                }
            }

            $pdf->writeHTML($html, true, false, true, false, '');
            $pdf->Output('patient_details_' . $mobile . '.pdf', 'D');
            exit();
        } catch (Exception $e) {
            error_log("patient.php: PDF generation error - " . $e->getMessage());
            $error_message = "PDF generation error: " . htmlspecialchars($e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard - THDC India Limited</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        .error { color: red; }
        .reg-card, .prescription-card, .pharmacy-card, .lab-card {
            border: 1px solid #ccc;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .card-title {
            color: #2c3e50;
            font-size: 1.2em;
            margin-bottom: 10px;
        }
        .section-title {
            color: #2980b9;
            margin-top: 20px;
            border-bottom: 2px solid #2980b9;
            padding-bottom: 5px;
        }
        button { margin-top: 10px; padding: 10px 20px; background-color: #2980b9; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background-color: #2c3e50; }
    </style>
</head>
<body>
    <header>
        <img src="thdclogo.png" alt="THDC India Limited Logo" class="logo">
        <h1>THDC India Limited</h1>
        <h2>Hospital Bhagirathi Puram, Tehri</h2>

         <div>
                <a href="logout.php" style="text-decoration: none;">
                    <button style="padding: 10px 15px; background-color: #dc3545; color: white; border: none; border-radius: 5px; cursor: pointer; margin-top: 10px;">
                        Logout
                    </button>
                </a>
            </div>
    </header>

    <div class="container">
        <h3>Patient Dashboard</h3>

        <form action="patient.php" method="POST">
            <label for="mobile">Mobile Number:</label>
            <input type="tel" id="mobile" name="mobile" pattern="[0-9]{10}" placeholder="Enter 10-digit mobile number" required>
            <button type="submit">View Details</button>
        </form>

        <?php if ($error_message): ?>
            <p class="error"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>

        <?php if (!empty($registrations)): ?>
            <h4>Welcome, <?php echo htmlspecialchars($registrations[0]['name'] ?? 'Patient'); ?></h4>
            <p><strong>Mobile Number:</strong> <?php echo htmlspecialchars($mobile); ?></p>

            <!-- Download PDF Button -->
            <?php if ($tcpdf_available): ?>
                <form action="patient.php" method="POST">
                    <input type="hidden" name="mobile" value="<?php echo htmlspecialchars($mobile); ?>">
                    <button type="submit" name="download_pdf">Download PDF</button>
                </form>
            <?php else: ?>
                <p class="error">PDF download is not available. Contact the administrator.</p>
            <?php endif; ?>

            <!-- Registrations Section -->
            <h4 class="section-title">Previous Registrations</h4>
            <?php foreach ($registrations as $reg): ?>
                <div class="reg-card">
                    <div class="card-title">Registration Details</div>
                    <p><strong>OPD Reg No:</strong> <?php echo htmlspecialchars($reg['opd_reg_no']); ?></p>
                    <p><strong>Name:</strong> <?php echo htmlspecialchars($reg['name']); ?></p>
                    <p><strong>Date:</strong> <?php echo (new DateTime($reg['reg_date']))->format('d-m-Y'); ?></p>
                    <p><strong>Department:</strong> <?php echo htmlspecialchars($reg['recommended_doctor'] ?? 'N/A'); ?></p>
                </div>
            <?php endforeach; ?>

            <!-- Prescriptions Section -->
            <h4 class="section-title">Doctor Prescriptions</h4>
            <?php if (empty($prescriptions)): ?>
                <p>No prescription records found.</p>
            <?php else: ?>
                <?php foreach ($prescriptions as $pres): ?>
                    <div class="prescription-card">
                        <div class="card-title"><?php echo $pres['medicine'] ? 'Medicine Prescription' : 'Lab Test Prescription'; ?></div>
                        <p><strong>OPD Reg No:</strong> <?php echo htmlspecialchars($pres['opd_reg_no']); ?></p>
                        <p><strong>Medicine:</strong> <?php echo htmlspecialchars($pres['medicine'] ?? 'N/A'); ?></p>
                        <p><strong>Lab Test:</strong> <?php echo htmlspecialchars($pres['lab_test'] ?? 'N/A'); ?></p>
                        <p><strong>Status:</strong> <?php echo htmlspecialchars($pres['status'] ?? 'N/A'); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <!-- Pharmacy Records Section -->
            <h4 class="section-title">Pharmacy Records</h4>
            <?php if (empty($pharmacy_records)): ?>
                <p>No pharmacy records found.</p>
            <?php else: ?>
                <?php foreach ($pharmacy_records as $pharm): ?>
                    <div class="pharmacy-card">
                        <div class="card-title">Pharmacy Record</div>
                        <p><strong>Pharmacist:</strong> <?php echo htmlspecialchars($pharm['pharmacist_name'] ?? 'N/A'); ?></p>
                        <p><strong>Date:</strong> <?php echo (new DateTime($pharm['dispense_date']))->format('d-m-Y'); ?></p>
                        <p><strong>Medication:</strong> <?php echo htmlspecialchars($pharm['medication'] ?? 'N/A'); ?></p>
                        <p><strong>Quantity:</strong> <?php echo htmlspecialchars($pharm['quantity'] ?? 'N/A'); ?></p>
                        <p><strong>Status:</strong> <?php echo htmlspecialchars($pharm['status'] ?? 'N/A'); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <!-- Lab Results Section -->
            <h4 class="section-title">Lab Results</h4>
            <?php if (empty($lab_results)): ?>
                <p>No lab results found.</p>
            <?php else: ?>
                <?php foreach ($lab_results as $lab): ?>
                    <div class="lab-card">
                        <div class="card-title">Lab Result</div>
                        <p><strong>Test Name:</strong> <?php echo htmlspecialchars($lab['test_name'] ?? 'N/A'); ?></p>
                        <p><strong>Date:</strong> <?php echo (new DateTime($lab['test_date']))->format('d-m-Y'); ?></p>
                        <p><strong>Result:</strong> <?php echo htmlspecialchars($lab['result'] ?? 'N/A'); ?></p>
                        <p><strong>Reference Range:</strong> <?php echo htmlspecialchars($lab['reference_range'] ?? 'N/A'); ?></p>
                        <p><strong>Status:</strong> <?php echo htmlspecialchars($lab['status'] ?? 'N/A'); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>