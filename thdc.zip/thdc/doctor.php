<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'config.php';

// Verify database connection
if (!$conn) {
    die("<p style='color: red;'><strong>❌ Database connection failed. Please check config.php.</strong></p>");
}

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'doctor') {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['opd_reg_no']) && !isset($_POST['complete'])) {
    $opd_reg_no = $_POST['opd_reg_no'];
    $medicine = $_POST['medicine'];
    $lab_test = $_POST['lab_test'];
    $doctor_id = $_SESSION['user_id'];

    try {
        $stmt = $conn->prepare("INSERT INTO prescriptions (opd_reg_no, doctor_id, medicine, lab_test) VALUES (:opd_reg_no, :doctor_id, :medicine, :lab_test)");
        $stmt->execute([':opd_reg_no' => $opd_reg_no, ':doctor_id' => $doctor_id, ':medicine' => $medicine, ':lab_test' => $lab_test]);
        echo "<p style='color: #28a745;'><strong>✅ Prescription submitted successfully!</strong></p>";
    } catch (PDOException $e) {
        echo "<p style='color: red;'><strong>❌ Error submitting prescription: " . htmlspecialchars($e->getMessage()) . "</strong></p>";
    }
}

// Handle marking prescription as complete
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['complete']) && isset($_POST['opd_reg_no'])) {
    $opd_reg_no = $_POST['opd_reg_no'];
    try {
        $stmt = $conn->prepare("UPDATE prescriptions SET status = 'completed' WHERE opd_reg_no = :opd_reg_no");
        $stmt->execute([':opd_reg_no' => $opd_reg_no]);
        echo "<p style='color: #28a745;'><strong>✅ Prescription marked as completed!</strong></p>";
    } catch (PDOException $e) {
        echo "<p style='color: red;'><strong>❌ Error marking prescription as completed: " . htmlspecialchars($e->getMessage()) . "</strong></p>";
    }
}

// Fetch all patient registrations that are not completed
try {
    $stmt = $conn->prepare("SELECT r.opd_reg_no, r.reg_date, r.name, r.age, r.gender, r.mobile, r.email, r.category, r.employee_name, r.relationship, r.workplace, r.recommended_doctor 
                            FROM registrations r 
                            LEFT JOIN prescriptions p ON r.opd_reg_no = p.opd_reg_no 
                            WHERE p.status IS NULL OR p.status != 'completed' 
                            ORDER BY r.reg_date DESC");
    $stmt->execute();
    $registrations = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p style='color: red;'><strong>❌ Error fetching registrations: " . htmlspecialchars($e->getMessage()) . "</strong></p>";
    $registrations = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>THDC India Limited - Doctor Portal</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #003087;
            color: white;
            padding: 10px 20px;
            text-align: center;
        }
        header div {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
        }
        .logo {
            height: 50px;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h3, h4 {
            color: #003087;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 30px;
        }
        label {
            font-weight: bold;
            color: #333;
        }
        input, textarea, button {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[readonly] {
            background-color: #e9ecef;
            cursor: not-allowed;
        }
        textarea {
            resize: vertical;
            min-height: 100px;
            font-family: Arial, sans-serif;
        }
        button {
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #218838;
        }
        .complete-btn {
            background-color: #dc3545;
        }
        .complete-btn:hover {
            background-color: #c82333;
        }
        .show-registrations-btn {
            margin-bottom: 20px;
            background-color: #007bff;
        }
        .show-registrations-btn:hover {
            background-color: #0056b3;
        }
        .registrations-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            display: none;
        }
        .registrations-table.active {
            display: table;
        }
        .registrations-table th, .registrations-table td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        .registrations-table th {
            background-color: #003087;
            color: white;
        }
        .registrations-table tr {
            cursor: pointer;
            transition: background-color 0.2s;
        }
        .registrations-table tr:hover {
            background-color: #f1f1f1;
        }
        .registrations-table tr.selected {
            background-color: #e0e7ff;
        }
        .patient-details {
            margin-top: 20px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        .patient-details p {
            margin: 5px 0;
        }
        @media (max-width: 768px) {
            header div {
                flex-direction: column;
                gap: 10px;
            }
            .container {
                margin: 10px;
                padding: 15px;
            }
            .registrations-table {
                font-size: 14px;
            }
            .registrations-table th, .registrations-table td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div>
            <div>
                <img src="thdclogo.png" alt="THDC India Limited Logo" class="logo">
                <h1>THDC India Limited</h1>
                <h2>Hospital Bhagirathi Puram, Tehri</h2>
            </div>
            <div>
                <a href="logout.php" style="text-decoration: none;">
                    <button style="padding: 10px 15px; background-color: #dc3545; color: white; border: none; border-radius: 5px; cursor: pointer; margin-top: 10px;">
                        Logout
                    </button>
                </a>
            </div>
        </div>
    </header>
    <div class="container">
        <h3>Doctor Portal</h3>
        <button class="show-registrations-btn" onclick="toggleRegistrations()">Show All Registrations</button>
        <h4>Patient Registrations</h4>
        <table class="registrations-table" id="registrations-table">
            <thead>
                <tr>
                    <th>OPD Reg No</th>
                    <th>Reg Date</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Mobile</th>
                    <th>Category</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($registrations)): ?>
                    <tr><td colspan="7">No active registrations found.</td></tr>
                <?php else: ?>
                    <?php foreach ($registrations as $reg): ?>
                        <tr data-opd-reg-no="<?php echo htmlspecialchars($reg['opd_reg_no']); ?>" 
                            data-patient-details='<?php echo json_encode([
                                'name' => htmlspecialchars($reg['name']),
                                'age' => htmlspecialchars($reg['age']),
                                'gender' => htmlspecialchars($reg['gender']),
                                'mobile' => htmlspecialchars($reg['mobile']),
                                'email' => htmlspecialchars($reg['email']),
                                'category' => htmlspecialchars($reg['category']),
                                'employee_name' => htmlspecialchars($reg['employee_name']),
                                'relationship' => htmlspecialchars($reg['relationship']),
                                'workplace' => htmlspecialchars($reg['workplace']),
                                'recommended_doctor' => htmlspecialchars($reg['recommended_doctor'])
                            ]); ?>'>
                            <td><?php echo htmlspecialchars($reg['opd_reg_no']); ?></td>
                            <td><?php echo date('d-m-Y H:i:s', strtotime($reg['reg_date'])); ?></td>
                            <td><?php echo htmlspecialchars($reg['name']); ?></td>
                            <td><?php echo htmlspecialchars($reg['age']); ?></td>
                            <td><?php echo htmlspecialchars($reg['gender']); ?></td>
                            <td><?php echo htmlspecialchars($reg['mobile']); ?></td>
                            <td><?php echo htmlspecialchars($reg['category']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <h4>Prescribe for Patient</h4>
        <form action="" method="POST" id="prescription-form">
            <label for="opd_reg_no">OPD Reg No:</label>
            <input type="text" id="opd_reg_no" name="opd_reg_no" readonly required>
            <div class="patient-details" id="patient-details"></div>
            <label for="medicine">Prescribe Medicine (one per line):</label>
            <textarea id="medicine" name="medicine" placeholder="e.g., 1) ABC Medicine 50mg&#10;2) XYZ Tablet 100mg"></textarea>
            <label for="lab_test">Recommended Lab Test (one per line):</label>
            <textarea id="lab_test" name="lab_test" placeholder="e.g., 1) Blood Test&#10;2) X-Ray"></textarea>
            <button type="submit">Submit Prescription</button>
            <button type="submit" name="complete" class="complete-btn" id="complete-btn" disabled>Mark as Completed</button>
        </form>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const rows = document.querySelectorAll('.registrations-table tr');
            const opdInput = document.getElementById('opd_reg_no');
            const patientDetails = document.getElementById('patient-details');
            const completeBtn = document.getElementById('complete-btn');

            rows.forEach(row => {
                row.addEventListener('click', function () {
                    // Remove selected class from all rows
                    rows.forEach(r => r.classList.remove('selected'));
                    // Add selected class to clicked row
                    this.classList.add('selected');

                    // Set OPD Reg No
                    const opdRegNo = this.dataset.opdRegNo;
                    opdInput.value = opdRegNo;

                    // Enable complete button and set its value
                    completeBtn.disabled = false;
                    completeBtn.setAttribute('value', opdRegNo);

                    // Display patient details from data attribute
                    const patientData = JSON.parse(this.dataset.patientDetails);
                    patientDetails.innerHTML = `
                        <p><strong>Name:</strong> ${patientData.name}</p>
                        <p><strong>Age:</strong> ${patientData.age}</p>
                        <p><strong>Gender:</strong> ${patientData.gender}</p>
                        <p><strong>Mobile:</strong> ${patientData.mobile}</p>
                        <p><strong>Email:</strong> ${patientData.email}</p>
                        <p><strong>Category:</strong> ${patientData.category}</p>
                        ${patientData.employee_name ? `<p><strong>Employee Name:</strong> ${patientData.employee_name}</p>` : ''}
                        ${patientData.relationship ? `<p><strong>Relationship:</strong> ${patientData.relationship}</p>` : ''}
                        ${patientData.workplace ? `<p><strong>Workplace:</strong> ${patientData.workplace}</p>` : ''}
                        <p><strong>Recommended Doctor:</strong> ${patientData.recommended_doctor}</p>
                    `;
                });
            });

            // Ensure the complete button submits the OPD Reg No
            completeBtn.addEventListener('click', function() {
                opdInput.removeAttribute('readonly'); // Temporarily allow form to submit opd_reg_no
            });
        });

        function toggleRegistrations() {
            const table = document.getElementById('registrations-table');
            const button = document.querySelector('.show-registrations-btn');
            table.classList.toggle('active');
            button.textContent = table.classList.contains('active') ? 'Hide Registrations' : 'Show All Registrations';
        }
    </script>
</body>
</html>