<?php
$host = 'sql213.infinityfree.com';
$dbname = 'if0_39532257_thdc_hospital';
$username = 'if0_39532257';
$password = 'qy4NDgAMQTTX';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>