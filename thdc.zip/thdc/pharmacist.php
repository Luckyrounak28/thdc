<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'config.php';

// Verify database connection
if (!$conn) {
    die("<p style='color: red;'><strong>❌ Database connection failed. Please check config.php.</strong></p>");
}

session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pharmacist') {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['opd_reg_no'])) {
    $opd_reg_no = $_POST['opd_reg_no'];
    $status = isset($_POST['status']) && $_POST['status'] == '1' ? 'not_available' : 'completed';
    try {
        $stmt = $conn->prepare("UPDATE prescriptions SET status = :status WHERE opd_reg_no = :opd_reg_no");
        $stmt->execute([':status' => $status, ':opd_reg_no' => $opd_reg_no]);
        echo "<p style='color: #28a745;'><strong>✅ Status updated successfully!</strong></p>";
    } catch (PDOException $e) {
        echo "<p style='color: red;'><strong>❌ Error updating status: " . htmlspecialchars($e->getMessage()) . "</strong></p>";
    }
}

// Fetch all prescriptions with patient details
try {
    $stmt = $conn->prepare("
        SELECT p.opd_reg_no, p.medicine, p.lab_test, p.status, r.name, r.age, r.gender, r.mobile
        FROM prescriptions p
        JOIN registrations r ON p.opd_reg_no = r.opd_reg_no
        ORDER BY p.id DESC
    ");
    $stmt->execute();
    $prescriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p style='color: red;'><strong>❌ Error fetching prescriptions: " . htmlspecialchars($e->getMessage()) . "</strong></p>";
    $prescriptions = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>THDC India Limited - Pharmacist Portal</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #003087;
            color: white;
            padding: 10px 20px;
            text-align: center;
        }
        header div {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
        }
        .logo {
            height: 50px;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h3, h4 {
            color: #003087;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 30px;
        }
        label {
            font-weight: bold;
            color: #333;
        }
        input[type="text"], button {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[readonly] {
            background-color: #e9ecef;
            cursor: not-allowed;
        }
        button {
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #218838;
        }
        .show-prescriptions-btn {
            margin-bottom: 20px;
            background-color: #007bff;
        }
        .show-prescriptions-btn:hover {
            background-color: #0056b3;
        }
        .prescriptions-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            display: none;
        }
        .prescriptions-table.active {
            display: table;
        }
        .prescriptions-table th, .prescriptions-table td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
            white-space: pre-wrap; /* Preserve line breaks for multi-line text */
        }
        .prescriptions-table th {
            background-color: #003087;
            color: white;
        }
        .prescriptions-table tr {
            cursor: pointer;
            transition: background-color 0.2s;
        }
        .prescriptions-table tr:hover {
            background-color: #f1f1f1;
        }
        .prescriptions-table tr.selected {
            background-color: #e0e7ff;
        }
        .prescription-details {
            margin-top: 20px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        .prescription-details p {
            margin: 5px 0;
            white-space: pre-wrap; /* Preserve line breaks in details */
        }
        @media (max-width: 768px) {
            header div {
                flex-direction: column;
                gap: 10px;
            }
            .container {
                margin: 10px;
                padding: 15px;
            }
            .prescriptions-table {
                font-size: 14px;
            }
            .prescriptions-table th, .prescriptions-table td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div>
            <div>
                <img src="thdclogo.png" alt="THDC India Limited Logo" class="logo">
                <h1>THDC India Limited</h1>
                <h2>Hospital Bhagirathi Puram, Tehri</h2>
            </div>
            <div>
                <a href="logout.php" style="text-decoration: none;">
                    <button style="padding: 10px 15px; background-color: #dc3545; color: white; border: none; border-radius: 5px; cursor: pointer; margin-top: 10px;">
                        Logout
                    </button>
                </a>
            </div>
        </div>
    </header>
    <div class="container">
        <h3>Pharmacist Portal</h3>
        <button class="show-prescriptions-btn" onclick="togglePrescriptions()">Show All Prescriptions</button>
        <h4>Prescriptions</h4>
        <table class="prescriptions-table" id="prescriptions-table">
            <thead>
                <tr>
                    <th>OPD Reg No</th>
                    <th>Patient Name</th>
                    <th>Medicine</th>
                    <th>Lab Test</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($prescriptions)): ?>
                    <tr><td colspan="5">No prescriptions found.</td></tr>
                <?php else: ?>
                    <?php foreach ($prescriptions as $pres): ?>
                        <tr data-opd-reg-no="<?php echo htmlspecialchars($pres['opd_reg_no']); ?>" 
                            data-prescription-details='<?php echo json_encode([
                                'name' => htmlspecialchars($pres['name']),
                                'age' => htmlspecialchars($pres['age']),
                                'gender' => htmlspecialchars($pres['gender']),
                                'mobile' => htmlspecialchars($pres['mobile']),
                                'medicine' => htmlspecialchars($pres['medicine']),
                                'lab_test' => htmlspecialchars($pres['lab_test']),
                                'status' => htmlspecialchars($pres['status'])
                            ]); ?>'>
                            <td><?php echo htmlspecialchars($pres['opd_reg_no']); ?></td>
                            <td><?php echo htmlspecialchars($pres['name']); ?></td>
                            <td><?php echo htmlspecialchars($pres['medicine']); ?></td>
                            <td><?php echo htmlspecialchars($pres['lab_test'] ?: 'None'); ?></td>
                            <td><?php echo htmlspecialchars($pres['status'] ?: 'Pending'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <h4>Update Prescription Status</h4>
        <form action="" method="POST" id="status-form">
            <label for="opd_reg_no">OPD Reg No:</label>
            <input type="text" id="opd_reg_no" name="opd_reg_no" readonly required>
            <div class="prescription-details" id="prescription-details"></div>
            <label for="status">Medicine Not Available:</label>
            <input type="checkbox" id="status" name="status" value="1">
            <button type="submit">Update Status</button>
        </form>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const rows = document.querySelectorAll('.prescriptions-table tr');
            const opdInput = document.getElementById('opd_reg_no');
            const prescriptionDetails = document.getElementById('prescription-details');
            const statusCheckbox = document.getElementById('status');

            rows.forEach(row => {
                row.addEventListener('click', function () {
                    // Remove selected class from all rows
                    rows.forEach(r => r.classList.remove('selected'));
                    // Add selected class to clicked row
                    this.classList.add('selected');

                    // Set OPD Reg No
                    const opdRegNo = this.dataset.opdRegNo;
                    opdInput.value = opdRegNo;

                    // Display prescription and patient details
                    const data = JSON.parse(this.dataset.prescriptionDetails);
                    prescriptionDetails.innerHTML = `
                        <p><strong>Patient Name:</strong> ${data.name}</p>
                        <p><strong>Age:</strong> ${data.age}</p>
                        <p><strong>Gender:</strong> ${data.gender}</p>
                        <p><strong>Mobile:</strong> ${data.mobile}</p>
                        <p><strong>Medicine:</strong> ${data.medicine}</p>
                        <p><strong>Lab Test:</strong> ${data.lab_test || 'None'}</p>
                        <p><strong>Status:</strong> ${data.status || 'Pending'}</p>
                    `;
                    // Set checkbox based on status
                    statusCheckbox.checked = data.status === 'not_available';
                });
            });

            // Ensure opd_reg_no is submitted with the form
            document.getElementById('status-form').addEventListener('submit', function() {
                opdInput.removeAttribute('readonly');
            });
        });

        function togglePrescriptions() {
            const table = document.getElementById('prescriptions-table');
            const button = document.querySelector('.show-prescriptions-btn');
            table.classList.toggle('active');
            button.textContent = table.classList.contains('active') ? 'Hide Prescriptions' : 'Show All Prescriptions';
        }
    </script>
</body>
</html>