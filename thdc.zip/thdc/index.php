<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set error log file
ini_set('log_errors', 1);
ini_set('error_log', 'error.log');

session_start();
error_log("index.php: Script started");

try {
    include 'config.php';
    error_log("index.php: config.php included successfully");
} catch (Exception $e) {
    error_log("index.php: Failed to include config.php - " . $e->getMessage());
    die("Error: Unable to include config.php. Check file path and permissions.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    error_log("index.php: POST request received");
    $role = $_POST['role'] ?? '';
    error_log("index.php: Role selected - $role");

    try {
        if ($role === 'patient') {
            $mobile = trim($_POST['mobile'] ?? '');
            error_log("index.php: Patient access attempt with mobile = '$mobile'");

            if (empty($mobile)) {
                error_log("index.php: Mobile number is empty");
                echo "<script>alert('Please enter a mobile number!'); window.location.href='index.php';</script>";
                exit();
            }

            if (!preg_match('/^[0-9]{10}$/', $mobile)) {
                error_log("index.php: Invalid mobile number format - '$mobile'");
                echo "<script>alert('Please enter a valid 10-digit mobile number!'); window.location.href='index.php';</script>";
                exit();
            }

            // Verify mobile number in registrations table
            $stmt = $conn->prepare("SELECT opd_reg_no FROM registrations WHERE mobile = :mobile");
            error_log("index.php: Executing query: SELECT opd_reg_no FROM registrations WHERE mobile = '$mobile'");
            $stmt->execute([':mobile' => $mobile]);
            $registration = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($registration) {
                error_log("index.php: Patient mobile verified, redirecting to patient.php");
                ?>
                <form id="redirectForm" action="patient.php" method="POST">
                    <input type="hidden" name="mobile" value="<?php echo htmlspecialchars($mobile); ?>">
                </form>
                <script>document.getElementById('redirectForm').submit();</script>
                <?php
                exit();
            } else {
                error_log("index.php: Invalid mobile number");
                echo "<script>alert('Invalid mobile number! No records found.'); window.location.href='index.php';</script>";
                exit();
            }
        } else {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            error_log("index.php: Non-patient login attempt with username = '$username', role = '$role'");

            if (empty($username) || empty($password)) {
                error_log("index.php: Username or password is empty");
                echo "<script>alert('Please enter both username and password!'); window.location.href='index.php';</script>";
                exit();
            }

            $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = :username AND role = :role");
            error_log("index.php: Executing query: SELECT id, password FROM users WHERE username = '$username' AND role = '$role'");
            $stmt->execute([':username' => $username, ':role' => $role]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && $password === $user['password']) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $role;
                $_SESSION['username'] = $username;

                $redirectMap = [
                    'receptionist' => 'register.html',
                    'doctor' => 'doctor.php',
                    'pharmacist' => 'pharmacist.php',
                    'lab' => 'lab.php',
                    'admin' => 'admin.php'
                ];

                $redirect = $redirectMap[$role] ?? 'index.php';
                error_log("index.php: Non-patient login successful, redirecting to $redirect");
                header("Location: $redirect");
                exit();
            } else {
                error_log("index.php: Invalid credentials for non-patient login");
                echo "<script>alert('Invalid credentials!'); window.location.href='index.php';</script>";
                exit();
            }
        }
    } catch (PDOException $e) {
        error_log("index.php: Database error - " . $e->getMessage());
        echo "<script>alert('Database error: " . addslashes($e->getMessage()) . "'); window.location.href='index.php';</script>";
        exit();
    } catch (Exception $e) {
        error_log("index.php: General error - " . $e->getMessage());
        echo "<script>alert('Error: " . addslashes($e->getMessage()) . "'); window.location.href='index.php';</script>";
        exit();
    }
} else {
    error_log("index.php: Not a POST request, displaying form");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>THDC India Limited - Access Portal</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        .error { color: red; }
        .reg-card, .prescription-card, .pharmacy-card, .lab-card {
            border: 1px solid #ccc;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .card-title {
            color: #2c3e50;
            font-size: 1.2em;
            margin-bottom: 10px;
        }
        .section-title {
            color: #2980b9;
            margin-top: 20px;
            border-bottom: 2px solid #2980b9;
            padding-bottom: 5px;
        }
        button { padding: 10px 20px; background-color: #2980b9; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background-color: #2c3e50; }
    </style>
    <script>
        function toggleFields() {
            var role = document.getElementById('role').value;
            var usernameField = document.getElementById('username-field');
            var passwordField = document.getElementById('password-field');
            var mobileField = document.getElementById('mobile-field');

            if (role === 'patient') {
                usernameField.style.display = 'none';
                passwordField.style.display = 'none';
                mobileField.style.display = 'block';
                document.getElementById('username').removeAttribute('required');
                document.getElementById('password').removeAttribute('required');
                document.getElementById('mobile').setAttribute('required', 'required');
            } else {
                usernameField.style.display = 'block';
                passwordField.style.display = 'block';
                mobileField.style.display = 'none';
                document.getElementById('username').setAttribute('required', 'required');
                document.getElementById('password').setAttribute('required', 'required');
                document.getElementById('mobile').removeAttribute('required');
            }
        }
    </script>
</head>
<body>
    <header>
        <img src="thdclogo.png" alt="THDC India Limited Logo" class="logo">
        <h1>THDC India Limited</h1>
        <h2>Hospital Bhagirathi Puram, Tehri</h2>
    </header>

    <div class="container">
        <h3>Access Portal</h3>

        <form action="index.php" method="POST">
            <label for="role">Role:</label>
            <select id="role" name="role" onchange="toggleFields()" required>
                <option value="">-- Select Role --</option>
                <option value="receptionist">Receptionist</option>
                <option value="doctor">Doctor</option>
                <option value="pharmacist">Pharmacist</option>
                <option value="lab">Lab</option>
                <option value="patient">Patient</option>
                <option value="admin">Admin</option>
            </select>

            <div id="username-field">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username">
            </div>

            <div id="password-field">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password">
            </div>

            <div id="mobile-field" style="display: none;">
                <label for="mobile">Mobile Number:</label>
                <input type="tel" id="mobile" name="mobile" pattern="[0-9]{10}" placeholder="Enter 10-digit mobile number" required>
            </div>

            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>